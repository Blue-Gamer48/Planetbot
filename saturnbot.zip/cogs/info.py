import discord
from discord import (
    SlashCommandOption as Option,
    ApplicationCommandInteraction as APPCI
)
from typing import Optional
from discord.ext import commands
from discord.ext.commands import Bot, Cog
from datetime import datetime
import platform
import speedtest
import os
import pytz
class info(commands.Cog):
    def __init__(self,bot: Bot):
        self.bot = bot
    @commands.Cog.slash_command(name="entwickler",description="gibt Infos zum Entwickler des Bots")
    async def entwickler(self,ctx):
        member = ctx.author
        embed = discord.Embed(title=f"Sourcecode Entwickler", description="Der Bot wird alleine von `Blue_Gamer48#3565` Entwickelt", color=0x03465c)
        embed.set_footer(text=f'Gesendet von: {ctx.author.name} • {ctx.author.id}',icon_url=ctx.author.avatar_url)
        await ctx.respond(embed=embed)
    @commands.Cog.slash_command(name="userinfo",description="Gibt Infos zu Einem User")
    async def userinfo(self, ctx,member: discord.Member=None):
        if member == None:
            member = ctx.author
        de = pytz.timezone("Europe/Berlin")
        self.embed = discord.Embed(title=f"Userinfo für {member.name}", description="", color=0x03465c,
                              timestamp=datetime.now().astimezone(tz=de))
        self.embed.add_field(name="Name", value=f"```{member.name}```", inline=False),
        self.embed.add_field(name='Bot', value=f'```{("Ja" if member.bot else "Nein")}```', inline=False)
        self.embed.add_field(name='Nickname', value=f'```{(member.nick if member.nick else "Nicht gesetzt")}```',
                        inline=True)
        self.embed.add_field(name='Server beigetreten', value=f'```{member.joined_at.date()}```', inline=False)
        self.embed.add_field(name='Discord beigetreten', value=f'```{member.created_at.date()}```', inline=False)
        self.embed.add_field(name='Rollen', value=f'```{len(member.roles)}```', inline=False)
        self.embed.add_field(name='Farbe', value=f'```{member.color}```', inline=False)
        self.embed.add_field(name='Booster', value=f'```{("Ja" if member.premium_since else "Nein")}```', inline=False)
        self.embed.add_field(name="Deine Rollen:", value=", ".join([role.mention for role in member.roles if not role.is_default()])),
        self.embed.set_footer(text=f'Gesendet von: {ctx.author.name} • {ctx.author.id}')
        self.embed.set_thumbnail(url=member.avatar_url)
        await ctx.respond(embed=self.embed)
    @commands.Cog.slash_command(name="botinfo",description="Infos zum Bot")
    async def botinfo(self,ctx):
        s = speedtest.Speedtest()
        s = s.results.dict()
        embed = discord.Embed(title=f"Botinfo von {self.bot.user.name}")
        embed.add_field(name="Name:", value=f"```{self.bot.user.name}```",inline=False)
        embed.add_field(name="Botinhaber",value="```Blue_Gamer48```")
        embed.add_field(name="Bot Version",value="```0.2.1```",inline=False)
        embed.add_field(name="Programmiersprache",value="```Python```",inline=False)
        embed.add_field(name="Programmiersprachen Version",value=f"```{platform.python_version()}```",inline=False)
        embed.add_field(name="Bibiliotek und Version",value=f"```{discord.__version__}```",inline=False)
        embed.add_field(name="Betriebsysystem und Version",value=f"```{platform.system()} {platform.release()} ({os.name}```",inline=False)
        embed.add_field(name="Bot:",value=f"```{s['client']['isp']}({s['client']['ip']}) {s['client']['country']} {s['client']['isprating']}```")
        await ctx.respond(embed=embed)

    @commands.Cog.slash_command(name="avatar",description="Gibt das profielbid eines Users aus")
    async def avatar(self, ctx, member: discord.Member=None):
        if member is None:
            embed = discord.Embed(title=f"Avatar von {ctx.author}", color=discord.Colour.blue())
            embed.set_image(url=ctx.author.avatar_url)
            await ctx.respond(embed=embed)
        else:
            embed = discord.Embed(title=f"Avatar von {member}", color=discord.Colour.blue())
            embed.set_image(url=member.avatar_url)
            await ctx.respond(embed=embed)
    @commands.Cog.slash_command(name="serverinfo",description="gibt infos zum Server aus")
    async def serverinfo(self,ctx):
        member = ctx.author
        embed = discord.Embed(title=f"Serverinfo {ctx.guild.name}", description="Informationzu Diesem Server",
                              color=discord.Colour.blue())
        embed.add_field(name='👑Inhaber:', value=f"{ctx.guild.owner}")
        embed.add_field(name='🆔Server ID:', value=f"{ctx.guild.id}",inline=False)
        embed.add_field(name='📆Erstellt am:', value=ctx.guild.created_at.strftime("%b %d %Y"), inline=False)
        embed.add_field(name='👥User:', value=f'{ctx.guild.member_count} Members',inline=False)
        embed.add_field(name='💬Kanäle: ',value=f'{len(ctx.guild.text_channels)} Text | {len(ctx.guild.voice_channels)} Sprachkanäle',inline=False)
        embed.set_thumbnail(url=ctx.guild.icon_url)
        embed.set_footer(text="⭐ • Erstellt von Blue_Gamer48",icon_url=member.avatar_url)
        await ctx.respond(embed=embed)
    @commands.Cog.slash_command(name="servericon")
    async def servericon(self,ctx):
        embed = discord.Embed(title=f"Avatar vom Server {ctx.guild}", color=discord.Colour.blue())
        embed.set_image(url=ctx.guild.icon_url)
        await ctx.respond(embed=embed)

    @commands.Cog.slash_command(name="channel_perms",
                                description="Zeigt die Berechtigungen die du auf einem Channels hast an",
                                options=[Option(name='channel',
                                description="geb den Channel an dessen perms du Sehen möchtest",
                                required=False,
                                option_type=discord.OptionType.channel)])
    async def channel_perms(self, ctx,channel: Optional[discord.abc.GuildChannel] = None,member: discord.Member=None):
        if member == None:
            member = ctx.author
            ctx.channel.permissions_for(member)
            permissions = (channel or ctx.channel).permissions_for(member)
            embed = discord.Embed(title=f':customs:  Permissions von {ctx.author} in {permissions}.value', color=0x3498db)
            embed.add_field(name='Server', value=ctx.guild)
            embed.add_field(name='Channel', value=ctx.channel, inline=False)
            for item, valueBool in permissions:
                if valueBool == True:
                    value = ':white_check_mark:'
                else:
                    value = ':x:'
                embed.add_field(name=item, value=value)
                embed.timestamp = datetime.utcnow()
            await ctx.respond(embed=embed)
    @commands.Cog.slash_command(name="speedtest",description="Gibt infos zur Geschwindigkeit des Bots")
    async def speedtest(self, ctx):
        await ctx.defer()
        s = speedtest.Speedtest()
        print("assigned")
        s.get_best_server()
        print("got server")
        s.download()
        print("calculated download")
        s.upload()
        print("calculated upload")
        s = s.results.dict()
        print("made dictionary")
        embed=discord.Embed(title=f"Geschwindigkeits Ttest von: {self.bot.user.name}",color=0x1a36a7)
        embed.add_field(name="Ping:",value=f"{s['ping']}ms")
        embed.add_field(name="Download:",value=f"{round(s['download']/10**6, 3)} Mbits/s")
        embed.add_field(name="Upload:", value=f"{round(s['upload']/10**6, 3)} Mbits/s")
        embed.add_field(name="Server:", value=f"{s['server']['sponsor']}, {s['server']['name']}, {s['server']['country']}")
        embed.add_field(name="Bot:", value=f"{s['client']['isp']}({s['client']['ip']}) {s['client']['country']}{s['client']['isprating']}")
        await ctx.respond(embed=embed)
    @commands.command(name="speedtest")
    async def speedtest(self, ctx):
        s = speedtest.Speedtest()
        print("assigned")
        s.get_best_server()
        print("got server")
        s.download()
        print("calculated download")
        s.upload()
        print("calculated upload")
        s = s.results.dict()
        print("made dictionary")
        embed=discord.Embed(title=f"Geschwindigkeits Ttest von: {self.bot.user.name}",color=0x1a36a7)
        embed.add_field(name="Ping:",value=f"{s['ping']}ms")
        embed.add_field(name="Download:",value=f"{round(s['download']/10**6, 3)} Mbits/s")
        embed.add_field(name="Upload:", value=f"{round(s['upload']/10**6, 3)} Mbits/s")
        embed.add_field(name="Server:", value=f"{s['server']['sponsor']}, {s['server']['name']}, {s['server']['country']}")
        embed.add_field(name="Bot:", value=f"{s['client']['isp']}({s['client']['ip']}) {s['client']['country']}{s['client']['isprating']}")
        await ctx.send(embed=embed)
    @commands.Cog.slash_command(name="roles",description="GZeigt dir eine Listedeiner Rollen")
    async def roles(self, ctx):
            embed = discord.Embed(title=f"Serverrollen von {ctx.guild}",
                                  description="\n".join([r.mention for r in ctx.guild.roles if not r.is_default()]),
                                  color=0x00ff00)
            embed.set_footer(text="ein Bot von Blue_Gamer48")
            await ctx.respond(embed=embed)

def setup(bot):
    bot.add_cog(info(bot))




