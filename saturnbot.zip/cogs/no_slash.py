import asyncio
import random
import discord
from discord.ext import commands
from discord.ext.commands import bot
from discord import ComponentInteraction, ModalSubmitInteraction, Modal, TextInput, Button, ButtonStyle
class allgemein(commands.Cog):
    def __init__(self, bot):
            self.bot = bot
   # @commands.command()
  #  async def delchannels(ctx):f
    #    for c in ctx.guild.channels: # iterating through each guild channel

     #   await c.delete()

def setup(bot):
    bot.add_cog(allgemein(bot))