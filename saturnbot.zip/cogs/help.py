import discord
from discord import ComponentInteraction
from discord.ext import commands
class help(commands.Cog):
    def __init__(self, bot):
            self.bot = bot

#    @commands.Cog.slash_command(name='help', description='Hilfe für den Discord bot')
#    async def help(self, ctx):
#        await ctx.respond('Role selection!', components=[
#            discord.SelectMenu(placeholder='Wähle aus wo du Hilfe Brauchst', custom_id='help', max_values=3, options=[
#                discord.SelectOption(label='1', value='1234567890', emoji='❤️'),
#                discord.SelectOption(label='Kälte', value='667129722995474460', emoji='❄️'),
#                discord.SelectOption(label='Party', value='667129769397059596', emoji='🎉'),
#            ])
#        )]
#    @commands.Cog.on_select(custom_id="helpmenu")
#    async def helpmenu_dropdown(self,ctx:ComponentInteraction, _):
#        for option in self.options:
#            if option.value.isdigit(1234567890):
#                await ctx.respond("1 wurde ausgewählt")
#
def setup(bot):
    bot.add_cog(help(bot))