import asyncio
import random
import discord
from discord.ext import commands
from discord.ext.commands import bot
from discord import ComponentInteraction, ModalSubmitInteraction, Modal, TextInput, Button, ButtonStyle
class allgemein(commands.Cog):
    def __init__(self, bot):
            self.bot = bot
    @commands.Cog.slash_command(name="gutenmorgen",description="Wünscht allen Usern einen Guten Morgen")
    async def gutenmorgen(self, ctx):
        embed_gm = discord.Embed(title="Einen wunderschönen guten Morgen.",description=f"der User {ctx.author.mention} wünscht euch einen Tollen Start in den Tag",color=0x00ff00)
        embed_gm.set_footer(text=f'Gesendet von: {ctx.author.name} • {ctx.author.id}', icon_url=ctx.author.avatar_url)
        await ctx.respond(embed=embed_gm)
    @commands.Cog.slash_command(name="gutenacht",description="Wünscht allen Usern eine Gute nacht")
    async def gutenacht(self, ctx):
        embed_gn = discord.Embed(title="Gute Nacht.",description=f"der User {ctx.author.mention} wünscht euch eine gute Nacht",color=0x00ff00)
        embed_gn.set_footer(text=f'Gesendet von: {ctx.author.name} • {ctx.author.id}', icon_url=ctx.author.avatar_url)
        await ctx.respond(embed=embed_gn)
    @commands.Cog.slash_command(name="invites",description="Zeigt den Invitelink zum Support Server und zum Bot")
    async def invites(self,ctx):
        embed_invites = discord.Embed(title=f'Zuhause von {self.bot.user}',
                              description=f"Trete dem Support Server bei! 🍻 [Zum Server](https://discord.gg/hSfYaxmez9)\n"
                                          f"Lade den Bot ein! 🍻 [Zum Botfenster](https://discord.com/oauth2/authorize?client_id=923162114187747328&permissions=8&scope=bot)",
                              color=0x3498db)
        embed_invites.set_footer(text=f'Gesendet von: {ctx.author.name} • {ctx.author.id}', icon_url=ctx.author.avatar_url)
        await ctx.respond(embed=embed_invites)
    @commands.Cog.slash_command(name="create_invite",description="Erstelle einen Serverinvite")
    async def serverinvite(self,ctx,):
        guild=ctx.author.guild
        invite = await guild.text_channels[0].create_invite(reason=None, max_age=0, max_uses=0, temporary=False,unique=True)
        embed_sinv = discord.Embed(title="Einladungslink Erstellt",description="",color=0x00ff00)
        embed_sinv.add_field(name="Link:", value=f"{invite}")
        embed_sinv.set_footer(text=f'Gesendet von: {ctx.author.name} • {ctx.author.id}', icon_url=ctx.author.avatar_url)
        await ctx.respond(embed=embed_sinv)
    @commands.Cog.slash_command(name="hallo",description="Sage Hallo")
    async def hallo(self, ctx):
        gifs = ['https://cdn.discordapp.com/attachments/102817255661772800/219512763607678976/large_1.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219512898563735552/large.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219518948251664384/WgQWD.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219518717426532352/tumblr_lnttzfSUM41qgcvsy.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219519191290478592/tumblr_mf76erIF6s1qj96p1o1_500.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219519729604231168/giphy_3.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219519737971867649/63953d32c650703cded875ac601e765778ce90d0_hq.gif',
                'https://cdn.discordapp.com/attachments/102817255661772800/219519738781368321/17201a4342e901e5f1bc2a03ad487219c0434c22_hq.gif']
        msg = f':wave: {random.choice(gifs)}'
        await ctx.respond(msg)
    @commands.Cog.slash_command(name="bugreport",description="Melde einen Fehler des Bots")
    async def bugreport(self, ctx):
        bugreport_modal = Modal(custom_id='bugreport',title='Melde einen Fehler.',components=[TextInput(custom_id='report_com_txt',label="Command",style=1,min_length=0,placeholder='Welcher Command ist Betroffen?'),
                                                                                              TextInput(custom_id='report_txt',label="Fehlermeldung",style=2,min_length=20,placeholder='Beschreibe den Fehler')])
        await ctx.respond_with_modal(modal=bugreport_modal)

    @commands.Cog.on_submit(custom_id='bugreport')
    async def bugreport_modal_callback(self, i: discord.ModalSubmitInteraction):
        report = i.get_field(custom_id="report_txt").value
        report_command = i.get_field(custom_id="report_com_txt").value
        try:
            embed_br_succes = discord.Embed(title="Fehlermeldung",color=discord.Colour.red())
            embed_br_succes.add_field(name="Meldender User:",value=i.author)
            embed_br_succes.add_field(name="ID des Melders:",value=i.author.id)
            embed_br_succes.add_field(name="Fehlerhafter Command:", value=report_command)
            embed_br_succes.add_field(name="Gemeldeter Fehler:",value=report)
            await self.bot.get_channel(927175725063213147).send(embed=embed_br_succes)
        except Exception as exc:
            embed_error_br = discord.Embed(title="Fehler",
                                           description=f"Es sieht so aus, als wäre etwas schief gelaufen:\n{exc}",
                                           color=discord.Colour.red())
            await i.respond(embed=embed_error_br)
            raise exc
        else:
            embed_br_succes_usr=discord.Embed(title="Fehler melden",description="Danke für das Melden des Fehlers ein Dev Schaut sich dasan und Behebt diesen er wird sich an dich wenden wenn es fragen gibt",colour=discord.Color.green())
            await i.respond(embed=embed_br_succes_usr)
def setup(bot):
    bot.add_cog(allgemein(bot))