import discord
from discord import (
    SlashCommandOption as Option,
    ApplicationCommandInteraction as APPCI
)
from typing import Optional
from discord.ext import commands
from discord.ext.commands import Bot, Cog
from datetime import datetime
import platform
import speedtest
import os
import pytz
class info(commands.Cog):
    def __init__(self,bot: Bot):
        self.bot = bot
    @commands.bot_has_permissions(manage_messages=True)
    @commands.has_permissions(manage_messages=True)
    @commands.command(name="clear",aliases=["clr"])
    async def clear(self, ctx, amount=100):
        if amount >100:
            await ctx.send("du darfst nicht mehr als 100 bereinigen")
            return
        await ctx.channel.purge(limit=amount)
        await ctx.send("Channel Bereinigung erfolgreich")
  #  @clear_error
   # async def clear_error(self, ctx, error):
   # if isinstance(error, commands.MissingPermissions):
   #     await ctx.send('**Du hast nicht die Berechtigung manage_messages!**')
def setup(bot):
    bot.add_cog(info(bot))