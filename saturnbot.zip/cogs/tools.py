import discord
from discord.ext import commands
from googletrans import Translator
class tools(commands.Cog):
    def __init__(self, bot):
        self.text = None
        self.bot = bot
    @commands.Cog.slash_command(name="translate",description="Übersetze einen Text")
    async def translate(self,ctx, lang, *, thing):
        translator = Translator()
        translation = translator.translate(thing, dest=lang)
        embed = discord.Embed(title=f"Übersetzer    :translate:",description=translation.text,color=0x00ff00)
        embed.set_footer(text="ein Bot von Blue_Gamer48")
        await ctx.respond(embed=embed)

def setup(bot):
    bot.add_cog(tools(bot))