import discord
INVITE_LINK = "https://discord.com/oauth2/authorize?client_id=923162114187747328&permissions=8&scope=bot"
WEBSITE_LINK = "https://saturn-bot.webnode.com/"
DISCORD_TOKEN = "OTM1MjM5MDQ5MjU2NTIxODY4.G3YUpB.OEdBmtZda0_A-JWXEVW_yYo7Z8sSnBt0t-XSic"
ERROR_CHANNEL = 938383256070549524
PREFIX = "s."